


## Relación entre foldes y capas

```
domain/entities             -->  Entities
domain/repositories         -->  Entities (contrato/interfaz)
application/usecases        -->  Use Cases
infrastructure/config       -->  Frameworks & Drivers (composition root)
infrastructure/composables  -->  Interface Adapters
infrastructure/repositories -->  Interface Adapters (gateway)
infrastructure/routes       -->  Frameworks & Drivers
```


Instalación

# Crear el proyecto Vue con Vite
npm create vue@latest inventory-f

# Las opciones que te pregunta Vite, para este proyecto:
# ✔ Add TypeScript?        No
# ✔ Add Vue Router?        Yes
# ✔ Add Pinia?             No
# ✔ Add Vitest?            No
# ✔ Add ESLint?            No

cd inventory-f
npm install

# Copiar tus carpetas domain/, application/ e infrastructure/
# dentro de src/ reemplazando lo que Vite genera

# Ejecutar
npm run dev

# Instalar UUID
npm install uuid

# Si presenta error de CORS
npm install cors

# Luego agregar en el src/app.js
import cors from "cors";
app.use(cors({ origin: '*' }));
